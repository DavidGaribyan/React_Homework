import './header.css';
import WrapperShadow from '../wrapperShadow/WrapperShadow.jsx';
import Wrapper from './headerWrapper/Wrapper.jsx';
import Logo from './Logo/LogoMain.jsx';
import HeaderList from './headerList/HeaderList.jsx';
import Notification from './Notification/Notification.jsx';
import LoginUser from './LoginUser/LoginUser.jsx';

export default function Header() {
  let headerListProps = {
    link_1: 'Как пользоваться?',
    link_2: 'Мои записи',
    link_3: 'Записаться к врачу',
  };

  let userName = {
    name: 'David Gharibyan',
  };

  return (
    <>
      <WrapperShadow>
        <Wrapper>
          <Logo />
          <div className="header__wrap">
            <HeaderList {...headerListProps} />
            <Notification notCount="3" />
            <LoginUser userName={userName.name} userLetter={userName.name.charAt(0)} />
          </div>
        </Wrapper>
      </WrapperShadow>
    </>
  );
}

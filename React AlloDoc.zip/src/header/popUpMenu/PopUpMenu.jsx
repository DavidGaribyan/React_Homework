import './popUpMenu.css';
import userIcon from './popUpIcons/usericon.png';
import balanceIcon from './popUpIcons/balance.png';
import helpIcon from './popUpIcons/helpicon.png';
import logOutIcon from './popUpIcons/logouticon.png';

export default function PopUpMenu() {
  return (
    <>
      <ul className="popUp__list">
        <li className="popUp__item">
          <button className="popUp__item-btn">
            <img src={userIcon} alt="icon" />
            <span className="popUp__itext">Мой профиль</span>
          </button>
        </li>
        <li className="popUp__item">
          <button className="popUp__item-btn">
            <img src={balanceIcon} alt="icon" />
            <span className="popUp__itext">Пополнить баланс</span>
          </button>
        </li>
        <li className="popUp__item">
          <button className="popUp__item-btn">
            <img src={helpIcon} alt="icon" />
            <span className="popUp__itext">FAQ</span>
          </button>
        </li>
        <li className="popUp__item">
          <button className="popUp__item-btn">
            <img src={logOutIcon} alt="icon" />
            <span className="popUp__itext">Выйти</span>
          </button>
        </li>
      </ul>
    </>
  );
}

import logo from './logo.png';

export default function Logo() {
  return (
    <>
      <img src={logo} alt="logo" />
    </>
  );
}

import WrapperMain from '../wrapperMain/WrapperMain.jsx';
import Consultations from './consultations/Consultation.jsx';
import BookDoc from './book/BookDoc.jsx';
import Notes from './notes/notesList/Notes.jsx';

export default function MainCont() {
  let bookContent = {
    bookHeading: 'Записаться к врачу',
    bookText: 'Более 1500 врачей и более 50 разных специализаций',
    bookListItem_1: 'Прием в удобное для вас время, без визита в клинику',
    bookListItem_2: 'Врачи с опытом работы более 8 лет',
    bookListItem_3: 'Понятно объясним причину недуга и дадим подробную рекомендацию',
    bookBtn: 'Записаться',
    myBooks: 'мои записи',
  };
  let notesList = {
    listItem_1: 'Предстоящие',
    listItem_2: 'Прошедшие',
    listItem_3: 'Отмененные',
  };
  return (
    <>
      <WrapperMain>
        <Consultations />
      </WrapperMain>
      <WrapperMain>
        <BookDoc {...bookContent} />
        <Notes {...notesList} />
      </WrapperMain>
    </>
  );
}

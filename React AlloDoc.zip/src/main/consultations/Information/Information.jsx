import './information.css';
import Button from '../button/InfoBtn.jsx';

export default function Information() {
  return (
    <>
      <div className="info__wrapper">
        <h1 className="information__heading">
          <span className="heading__decoration">Онлайн консультации</span> от врачей специалистов 24/7
        </h1>
        <p className="information__text">
          Проконсультируйтесь <span className="infoText__decor">сейчас</span> или по <span className="infoText__decor">предварительной записи</span> со своего компьютера или c помощью нашего приложения, доступного в <span className="stores__decor">App Store</span> и <span className="stores__decor">Google Play</span>
        </p>
        <Button className="white" btnName="Записаться" />
        <Button className="blue" btnName="Как это работает?" />
      </div>
    </>
  );
}

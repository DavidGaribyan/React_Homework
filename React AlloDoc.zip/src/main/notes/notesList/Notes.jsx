import './notes.css';
import NotesCard from '../notesCard/NotesCard.jsx';
import avatar from '../notesCard/notesIcons/avatar.png';
import calendar from '../notesCard/notesIcons/calendar.png';
import camera from '../notesCard/notesIcons/camera.png';
import clock from '../notesCard/notesIcons/clock.png';
import chat from '../notesCard/notesIcons/chat.png';

export default function Notes(props) {
  let user = [
    {
      avatar: avatar,
      name: 'Ольга Никитина',
      staff: 'Педиатр',
      stage: 'Стаж 15 лет',
      date: '03 Марта 2021 ',
      calendar: calendar,
      hour: '16:00',
      clock: clock,
      connection: 'Видео связь',
      camera: camera,
      condition: 'Запланировано',
      btn_1: 'Посмотреть запись',
      btn_2: 'Посмотреть постановление',
    },
    {
      avatar: avatar,
      name: 'Ангелина Марковна',
      staff: 'Оториноларинголог (ЛОР), Терапевт',
      stage: 'Стаж 5 лет',
      date: '16 Марта 2021 ',
      calendar: calendar,
      hour: '23:00',
      clock: clock,
      connection: 'Чат',
      camera: chat,
      condition: 'Запланировано',
      btn_1: 'Посмотреть запись',
      btn_2: 'Посмотреть постановление',
    },
    {
      avatar: avatar,
      name: 'Юлия Тихоновна',
      staff: 'Оториноларинголог (ЛОР), Терапевт',
      stage: 'Стаж 7 лет',
      date: '23 август 2022 ',
      calendar: calendar,
      hour: '23:00',
      clock: clock,
      connection: 'Видео связь',
      camera: camera,
      condition: 'Состоялась',
      btn_1: 'Посмотреть запись',
      btn_2: 'Посмотреть постановление',
    },
  ];
  return (
    <>
      <ul className="notes__list">
        <li className="notes__item">{props.listItem_1}</li>
        <li className="notes__item">{props.listItem_2}</li>
        <li className="notes__item">{props.listItem_3}</li>
      </ul>
      <NotesCard user={user} />
    </>
  );
}

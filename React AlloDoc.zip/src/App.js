import Header from './header/header.jsx';
import MainCont from './main/MainCont.jsx';
function App() {
  return (
    <>
      <Header />
      <MainCont />
    </>
  );
}

export default App;

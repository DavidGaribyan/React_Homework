import './wrapperMain.css';
export default function WrapperMain(props) {
  return <div className="wrapper__main">{props.children}</div>;
}
